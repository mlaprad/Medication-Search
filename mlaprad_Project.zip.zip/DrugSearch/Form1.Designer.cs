﻿
namespace DrugSearch
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label drug_genericLabel;
            System.Windows.Forms.Label drug_brandLabel;
            System.Windows.Forms.Label strengthLabel;
            System.Windows.Forms.Label descriptionLabel;
            System.Windows.Forms.Label dosage_formLabel;
            System.Windows.Forms.Label marketing_statusLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.drugDataSet = new DrugSearch.DrugDataSet();
            this.drugBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.drugTableAdapter = new DrugSearch.DrugDataSetTableAdapters.DrugTableAdapter();
            this.tableAdapterManager = new DrugSearch.DrugDataSetTableAdapters.TableAdapterManager();
            this.drugDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtboxGeneric = new System.Windows.Forms.TextBox();
            this.txtboxBrand = new System.Windows.Forms.TextBox();
            this.cmbSearch = new System.Windows.Forms.ComboBox();
            this.txtboxStrength = new System.Windows.Forms.TextBox();
            this.txtboxDescription = new System.Windows.Forms.TextBox();
            this.txtBoxForm = new System.Windows.Forms.TextBox();
            this.txtBoxStatus = new System.Windows.Forms.TextBox();
            this.picBoxLogo = new System.Windows.Forms.PictureBox();
            this.lblSearch = new System.Windows.Forms.Label();
            this.groupBoxDrug = new System.Windows.Forms.GroupBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            drug_genericLabel = new System.Windows.Forms.Label();
            drug_brandLabel = new System.Windows.Forms.Label();
            strengthLabel = new System.Windows.Forms.Label();
            descriptionLabel = new System.Windows.Forms.Label();
            dosage_formLabel = new System.Windows.Forms.Label();
            marketing_statusLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.drugDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.drugBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.drugDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxLogo)).BeginInit();
            this.groupBoxDrug.SuspendLayout();
            this.SuspendLayout();
            // 
            // drug_genericLabel
            // 
            drug_genericLabel.AutoSize = true;
            drug_genericLabel.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            drug_genericLabel.Location = new System.Drawing.Point(7, 72);
            drug_genericLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            drug_genericLabel.Name = "drug_genericLabel";
            drug_genericLabel.Size = new System.Drawing.Size(159, 23);
            drug_genericLabel.TabIndex = 2;
            drug_genericLabel.Text = "Generic Name:";
            // 
            // drug_brandLabel
            // 
            drug_brandLabel.AutoSize = true;
            drug_brandLabel.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            drug_brandLabel.Location = new System.Drawing.Point(7, 122);
            drug_brandLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            drug_brandLabel.Name = "drug_brandLabel";
            drug_brandLabel.Size = new System.Drawing.Size(139, 23);
            drug_brandLabel.TabIndex = 4;
            drug_brandLabel.Text = "Brand Name:";
            // 
            // strengthLabel
            // 
            strengthLabel.AutoSize = true;
            strengthLabel.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            strengthLabel.Location = new System.Drawing.Point(7, 172);
            strengthLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            strengthLabel.Name = "strengthLabel";
            strengthLabel.Size = new System.Drawing.Size(95, 23);
            strengthLabel.TabIndex = 7;
            strengthLabel.Text = "Strength:";
            // 
            // descriptionLabel
            // 
            descriptionLabel.AutoSize = true;
            descriptionLabel.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            descriptionLabel.Location = new System.Drawing.Point(601, 72);
            descriptionLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            descriptionLabel.Name = "descriptionLabel";
            descriptionLabel.Size = new System.Drawing.Size(122, 23);
            descriptionLabel.TabIndex = 9;
            descriptionLabel.Text = "Description:";
            // 
            // dosage_formLabel
            // 
            dosage_formLabel.AutoSize = true;
            dosage_formLabel.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dosage_formLabel.Location = new System.Drawing.Point(7, 221);
            dosage_formLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            dosage_formLabel.Name = "dosage_formLabel";
            dosage_formLabel.Size = new System.Drawing.Size(145, 23);
            dosage_formLabel.TabIndex = 11;
            dosage_formLabel.Text = "Dosage Form:";
            // 
            // marketing_statusLabel
            // 
            marketing_statusLabel.AutoSize = true;
            marketing_statusLabel.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            marketing_statusLabel.Location = new System.Drawing.Point(7, 271);
            marketing_statusLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            marketing_statusLabel.Name = "marketing_statusLabel";
            marketing_statusLabel.Size = new System.Drawing.Size(174, 23);
            marketing_statusLabel.TabIndex = 13;
            marketing_statusLabel.Text = "Marketing Status:";
            // 
            // drugDataSet
            // 
            this.drugDataSet.DataSetName = "DrugDataSet";
            this.drugDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // drugBindingSource
            // 
            this.drugBindingSource.DataMember = "Drug";
            this.drugBindingSource.DataSource = this.drugDataSet;
            // 
            // drugTableAdapter
            // 
            this.drugTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.DrugTableAdapter = this.drugTableAdapter;
            this.tableAdapterManager.UpdateOrder = DrugSearch.DrugDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // drugDataGridView
            // 
            this.drugDataGridView.AutoGenerateColumns = false;
            this.drugDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.drugDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7});
            this.drugDataGridView.DataSource = this.drugBindingSource;
            this.drugDataGridView.Location = new System.Drawing.Point(29, 577);
            this.drugDataGridView.Margin = new System.Windows.Forms.Padding(4);
            this.drugDataGridView.Name = "drugDataGridView";
            this.drugDataGridView.RowHeadersWidth = 51;
            this.drugDataGridView.RowTemplate.Height = 24;
            this.drugDataGridView.Size = new System.Drawing.Size(178, 85);
            this.drugDataGridView.TabIndex = 1;
            this.drugDataGridView.Visible = false;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "drug_id";
            this.dataGridViewTextBoxColumn1.HeaderText = "drug_id";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 125;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "drug_generic";
            this.dataGridViewTextBoxColumn2.HeaderText = "drug_generic";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "drug_brand";
            this.dataGridViewTextBoxColumn3.HeaderText = "drug_brand";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 125;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "strength";
            this.dataGridViewTextBoxColumn4.HeaderText = "strength";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 125;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "dosage_form";
            this.dataGridViewTextBoxColumn5.HeaderText = "dosage_form";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Width = 125;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "description";
            this.dataGridViewTextBoxColumn6.HeaderText = "description";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Width = 125;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "marketing_status";
            this.dataGridViewTextBoxColumn7.HeaderText = "marketing_status";
            this.dataGridViewTextBoxColumn7.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.Width = 125;
            // 
            // txtboxGeneric
            // 
            this.txtboxGeneric.BackColor = System.Drawing.Color.White;
            this.txtboxGeneric.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.drugBindingSource, "drug_generic", true));
            this.txtboxGeneric.Location = new System.Drawing.Point(189, 69);
            this.txtboxGeneric.Margin = new System.Windows.Forms.Padding(4);
            this.txtboxGeneric.Name = "txtboxGeneric";
            this.txtboxGeneric.ReadOnly = true;
            this.txtboxGeneric.Size = new System.Drawing.Size(383, 32);
            this.txtboxGeneric.TabIndex = 3;
            // 
            // txtboxBrand
            // 
            this.txtboxBrand.BackColor = System.Drawing.Color.White;
            this.txtboxBrand.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.drugBindingSource, "drug_brand", true));
            this.txtboxBrand.Location = new System.Drawing.Point(189, 119);
            this.txtboxBrand.Margin = new System.Windows.Forms.Padding(4);
            this.txtboxBrand.Name = "txtboxBrand";
            this.txtboxBrand.ReadOnly = true;
            this.txtboxBrand.Size = new System.Drawing.Size(383, 32);
            this.txtboxBrand.TabIndex = 5;
            // 
            // cmbSearch
            // 
            this.cmbSearch.DataSource = this.drugBindingSource;
            this.cmbSearch.DisplayMember = "drug_generic";
            this.cmbSearch.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSearch.FormattingEnabled = true;
            this.cmbSearch.Location = new System.Drawing.Point(424, 93);
            this.cmbSearch.Margin = new System.Windows.Forms.Padding(4);
            this.cmbSearch.Name = "cmbSearch";
            this.cmbSearch.Size = new System.Drawing.Size(483, 31);
            this.cmbSearch.TabIndex = 6;
            this.cmbSearch.ValueMember = "drug_brand";
            // 
            // txtboxStrength
            // 
            this.txtboxStrength.BackColor = System.Drawing.Color.White;
            this.txtboxStrength.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.drugBindingSource, "strength", true));
            this.txtboxStrength.Location = new System.Drawing.Point(189, 169);
            this.txtboxStrength.Margin = new System.Windows.Forms.Padding(4);
            this.txtboxStrength.Name = "txtboxStrength";
            this.txtboxStrength.ReadOnly = true;
            this.txtboxStrength.Size = new System.Drawing.Size(383, 32);
            this.txtboxStrength.TabIndex = 8;
            // 
            // txtboxDescription
            // 
            this.txtboxDescription.BackColor = System.Drawing.Color.White;
            this.txtboxDescription.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.drugBindingSource, "description", true));
            this.txtboxDescription.Location = new System.Drawing.Point(731, 69);
            this.txtboxDescription.Margin = new System.Windows.Forms.Padding(4);
            this.txtboxDescription.Multiline = true;
            this.txtboxDescription.Name = "txtboxDescription";
            this.txtboxDescription.ReadOnly = true;
            this.txtboxDescription.Size = new System.Drawing.Size(412, 161);
            this.txtboxDescription.TabIndex = 10;
            // 
            // txtBoxForm
            // 
            this.txtBoxForm.BackColor = System.Drawing.Color.White;
            this.txtBoxForm.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.drugBindingSource, "dosage_form", true));
            this.txtBoxForm.Location = new System.Drawing.Point(189, 218);
            this.txtBoxForm.Margin = new System.Windows.Forms.Padding(4);
            this.txtBoxForm.Name = "txtBoxForm";
            this.txtBoxForm.ReadOnly = true;
            this.txtBoxForm.Size = new System.Drawing.Size(383, 32);
            this.txtBoxForm.TabIndex = 12;
            // 
            // txtBoxStatus
            // 
            this.txtBoxStatus.BackColor = System.Drawing.Color.White;
            this.txtBoxStatus.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.drugBindingSource, "marketing_status", true));
            this.txtBoxStatus.Location = new System.Drawing.Point(189, 268);
            this.txtBoxStatus.Margin = new System.Windows.Forms.Padding(4);
            this.txtBoxStatus.Name = "txtBoxStatus";
            this.txtBoxStatus.ReadOnly = true;
            this.txtBoxStatus.Size = new System.Drawing.Size(383, 32);
            this.txtBoxStatus.TabIndex = 14;
            // 
            // picBoxLogo
            // 
            this.picBoxLogo.Image = global::DrugSearch.Properties.Resources.Medication_Search_Logo;
            this.picBoxLogo.InitialImage = ((System.Drawing.Image)(resources.GetObject("picBoxLogo.InitialImage")));
            this.picBoxLogo.Location = new System.Drawing.Point(18, 13);
            this.picBoxLogo.Margin = new System.Windows.Forms.Padding(4);
            this.picBoxLogo.Name = "picBoxLogo";
            this.picBoxLogo.Size = new System.Drawing.Size(229, 175);
            this.picBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxLogo.TabIndex = 15;
            this.picBoxLogo.TabStop = false;
            // 
            // lblSearch
            // 
            this.lblSearch.AutoSize = true;
            this.lblSearch.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearch.Location = new System.Drawing.Point(333, 96);
            this.lblSearch.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(83, 23);
            this.lblSearch.TabIndex = 16;
            this.lblSearch.Text = "Search:";
            // 
            // groupBoxDrug
            // 
            this.groupBoxDrug.Controls.Add(this.txtboxStrength);
            this.groupBoxDrug.Controls.Add(this.txtboxGeneric);
            this.groupBoxDrug.Controls.Add(drug_genericLabel);
            this.groupBoxDrug.Controls.Add(descriptionLabel);
            this.groupBoxDrug.Controls.Add(marketing_statusLabel);
            this.groupBoxDrug.Controls.Add(this.txtboxDescription);
            this.groupBoxDrug.Controls.Add(this.txtboxBrand);
            this.groupBoxDrug.Controls.Add(this.txtBoxStatus);
            this.groupBoxDrug.Controls.Add(drug_brandLabel);
            this.groupBoxDrug.Controls.Add(dosage_formLabel);
            this.groupBoxDrug.Controls.Add(strengthLabel);
            this.groupBoxDrug.Controls.Add(this.txtBoxForm);
            this.groupBoxDrug.Location = new System.Drawing.Point(18, 225);
            this.groupBoxDrug.Name = "groupBoxDrug";
            this.groupBoxDrug.Size = new System.Drawing.Size(1163, 345);
            this.groupBoxDrug.TabIndex = 17;
            this.groupBoxDrug.TabStop = false;
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.SystemColors.MenuBar;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Location = new System.Drawing.Point(1068, 602);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(89, 32);
            this.btnClose.TabIndex = 18;
            this.btnClose.Text = "Exit";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.SystemColors.MenuBar;
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClear.Location = new System.Drawing.Point(935, 93);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(89, 32);
            this.btnClear.TabIndex = 19;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(1203, 687);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.groupBoxDrug);
            this.Controls.Add(this.lblSearch);
            this.Controls.Add(this.picBoxLogo);
            this.Controls.Add(this.cmbSearch);
            this.Controls.Add(this.drugDataGridView);
            this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Navy;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Medication Search:";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.drugDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.drugBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.drugDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxLogo)).EndInit();
            this.groupBoxDrug.ResumeLayout(false);
            this.groupBoxDrug.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DrugDataSet drugDataSet;
        private System.Windows.Forms.BindingSource drugBindingSource;
        private DrugDataSetTableAdapters.DrugTableAdapter drugTableAdapter;
        private DrugDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView drugDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.TextBox txtboxGeneric;
        private System.Windows.Forms.TextBox txtboxBrand;
        private System.Windows.Forms.ComboBox cmbSearch;
        private System.Windows.Forms.TextBox txtboxStrength;
        private System.Windows.Forms.TextBox txtboxDescription;
        private System.Windows.Forms.TextBox txtBoxForm;
        private System.Windows.Forms.TextBox txtBoxStatus;
        private System.Windows.Forms.PictureBox picBoxLogo;
        private System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.GroupBox groupBoxDrug;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnClear;
    }
}

